/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bazastudentow;

/**
 *
 * @author paulinka
 */
public class Wyjatek0 extends Exception{
    
    public Wyjatek0(){
    }
    
    public Wyjatek0(String komunikat){
        super(komunikat);
    }
}
